from .python import linalg_core as _linalg_core

LinearAlgebra = _linalg_core.LinearAlgebra
